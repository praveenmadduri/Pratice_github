package com.praveenAngular.repo;

import org.springframework.data.repository.CrudRepository;

import com.praveenAngular.models.Contact;

public interface ContactRepository extends CrudRepository<Contact, String> {
    @Override
    void delete(Contact deleted);
}